<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('tb_kriteria', function (Blueprint $table) {
            $table->double('bobot', 8, 4)->nullable()->after('atribut');
        });
    }

    public function down()
    {
        Schema::table('tb_kriteria', function (Blueprint $table) {
            $table->dropColumn('bobot');
        });
    }
};
