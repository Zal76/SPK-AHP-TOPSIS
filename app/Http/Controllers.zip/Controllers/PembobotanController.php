<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Kriteria;

class PembobotanController extends Controller
{
    // Tampilkan halaman pembobotan
    public function index()
    {
        $kriterias = Kriteria::all();
        $relasi = DB::table('tb_rel_kriteria')->get();

        $matriks = [];
        foreach ($kriterias as $k1) {
            foreach ($kriterias as $k2) {
                $data = $relasi->where('ID1', $k1->kode_kriteria)
                               ->where('ID2', $k2->kode_kriteria)
                               ->first();

                $matriks[$k1->kode_kriteria][$k2->kode_kriteria] = $data->nilai ?? ($k1->kode_kriteria == $k2->kode_kriteria ? 1 : null);
            }
        }

        return view('pembobotan.index', compact('kriterias', 'matriks'));
    }

    // Update nilai perbandingan antar kriteria
    public function updateNilai(Request $request)
    {
        $k1 = $request->input('kriteria1');
        $k2 = $request->input('kriteria2');
        $nilai = floatval($request->input('nilai'));

        if ($k1 == $k2) {
            return back()->with('error', 'Kriteria tidak boleh sama.');
        }

        DB::table('tb_rel_kriteria')->updateOrInsert(
            ['ID1' => $k1, 'ID2' => $k2],
            ['nilai' => $nilai, 'tahun' => date('Y')]
        );

        DB::table('tb_rel_kriteria')->updateOrInsert(
            ['ID1' => $k2, 'ID2' => $k1],
            ['nilai' => 1 / $nilai, 'tahun' => date('Y')]
        );

        return back()->with('success', "Nilai perbandingan $k1 terhadap $k2 berhasil diperbarui!");
    }

    // Hitung bobot & konsistensi, simpan ke session
    public function hitung()
    {
        $kriterias = Kriteria::all();
        $relasi = DB::table('tb_rel_kriteria')->get();
        $n = count($kriterias);

        // 1. Matriks Perbandingan
        $matriks = [];
        foreach ($kriterias as $k1) {
            foreach ($kriterias as $k2) {
                $data = $relasi->where('ID1', $k1->kode_kriteria)
                               ->where('ID2', $k2->kode_kriteria)
                               ->first();
                $matriks[$k1->kode_kriteria][$k2->kode_kriteria] = $data->nilai ?? 1;
            }
        }

        // 2. Total kolom & normalisasi
        $totalKolom = [];
        foreach ($kriterias as $k2) {
            $totalKolom[$k2->kode_kriteria] = array_sum(array_column($matriks, $k2->kode_kriteria));
        }

        $bobot = [];
        foreach ($kriterias as $k1) {
            $jumlahBaris = 0;
            foreach ($kriterias as $k2) {
                $nilai = $matriks[$k1->kode_kriteria][$k2->kode_kriteria] / $totalKolom[$k2->kode_kriteria];
                $jumlahBaris += $nilai;
            }
            $bobot[$k1->kode_kriteria] = $jumlahBaris / $n;

            // Update bobot ke tabel (pastikan kolom 'bobot' ada di tb_kriteria)
            Kriteria::where('kode_kriteria', $k1->kode_kriteria)
                    ->update(['bobot' => $bobot[$k1->kode_kriteria]]);
        }

        // 3. Hitung Consistency Ratio
        $lamdaMax = 0;
        foreach ($kriterias as $k1) {
            $s = 0;
            foreach ($kriterias as $k2) {
                $s += $matriks[$k1->kode_kriteria][$k2->kode_kriteria] * $bobot[$k2->kode_kriteria];
            }
            $lamdaMax += $s / $bobot[$k1->kode_kriteria];
        }
        $lamdaMax /= $n; // λ max

        $ci = ($lamdaMax - $n) / ($n - 1); // Consistency Index
        $riTable = [0, 0, 0.58, 0.90, 1.12, 1.24, 1.32, 1.41, 1.45, 1.49]; // RI untuk n=1..10
        $ri = $riTable[$n] ?? 0;
        $cr = $ri ? $ci / $ri : 0;

        // Simpan ke session untuk digunakan di menu perhitungan TOPSIS
        session([
            'matriks' => $matriks,
            'bobot' => $bobot,
            'totalKolom' => $totalKolom,
            'lamdaMax' => $lamdaMax,
            'ci' => $ci,
            'ri' => $ri,
            'cr' => $cr
        ]);

        return redirect()->route('perhitungan.index')->with('success', 'Pembobotan selesai, siap untuk TOPSIS!');
    }
}
