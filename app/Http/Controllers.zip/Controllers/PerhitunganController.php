<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Alternatif;
use App\Models\Kriteria;
use App\Models\Penilaian; 

class PerhitunganController extends Controller
{
    public function index()
    {
        // Ambil data dari session AHP
        $matriks   = session('matriks', []);
        $bobot     = session('bobot', []); // hasil AHP
        $lamdaMax  = session('lamdaMax', 0);
        $ci        = session('ci', 0);
        $ri        = session('ri', 0);
        $cr        = session('cr', 0);
        $totalKolom = session('totalKolom', []);

        // Ambil data alternatif & kriteria
        $alternatifs = Alternatif::all();
        $kriterias   = Kriteria::all();

        // ====== 1. Matriks Keputusan (X) dari tabel Penilaian ======
            $penilaians = Penilaian::all();
            $topsis = [];

            foreach ($alternatifs as $alt) {
                foreach ($kriterias as $k) {
                    $nilai = $penilaians
                        ->where('alternatif_id', $alt->id)
                        ->where('kriteria_id', $k->id)
                        ->first()
                        ->nilai ?? 0;

                    $topsis[$alt->kode_alternatif][$k->kode_kriteria] = (float) $nilai;
                }
            }

        // ====== 2. Normalisasi ======
        $normalisasi = [];
        foreach ($kriterias as $k) {
            $kodeKriteria = $k->kode_kriteria;
            $sumKuadrat = 0;
            foreach ($alternatifs as $alt) {
                $sumKuadrat += pow($topsis[$alt->kode_alternatif][$kodeKriteria], 2);
            }
            $pembagi = sqrt($sumKuadrat);
            foreach ($alternatifs as $alt) {
                $normalisasi[$alt->kode_alternatif][$kodeKriteria] = $pembagi > 0
                    ? $topsis[$alt->kode_alternatif][$kodeKriteria] / $pembagi
                    : 0;
            }
        }

        // ====== 3. Matriks Terbobot ======
        $terbobot = [];
        foreach ($alternatifs as $alt) {
            foreach ($kriterias as $k) {
                $kodeKriteria = $k->kode_kriteria;
                $w = $bobot[$kodeKriteria] ?? 0;
                $terbobot[$alt->kode_alternatif][$kodeKriteria] = $normalisasi[$alt->kode_alternatif][$kodeKriteria] * $w;
            }
        }

        // ====== 4. Solusi Ideal Positif & Negatif ======
        $idealPositif = [];
        $idealNegatif = [];
        foreach ($kriterias as $k) {
            $kodeKriteria = $k->kode_kriteria;
            $values = array_column($terbobot, $kodeKriteria);

            if ($k->atribut == 'Benefit') {
                $idealPositif[$kodeKriteria] = max($values);
                $idealNegatif[$kodeKriteria] = min($values);
            } else {
                $idealPositif[$kodeKriteria] = min($values);
                $idealNegatif[$kodeKriteria] = max($values);
            }
        }

        // ====== 5. Hitung Jarak ======
        $dPositif = [];
        $dNegatif = [];
        foreach ($alternatifs as $alt) {
            $kodeAlt = $alt->kode_alternatif;
            $sumPos = $sumNeg = 0;
            foreach ($kriterias as $k) {
                $kodeKriteria = $k->kode_kriteria;
                $y = $terbobot[$kodeAlt][$kodeKriteria];
                $sumPos += pow($y - $idealPositif[$kodeKriteria], 2);
                $sumNeg += pow($y - $idealNegatif[$kodeKriteria], 2);
            }
            $dPositif[$kodeAlt] = sqrt($sumPos);
            $dNegatif[$kodeAlt] = sqrt($sumNeg);
        }

        // ====== 6. Nilai Preferensi (Skor Akhir) ======
        $preferensi = [];
        foreach ($alternatifs as $alt) {
            $kodeAlt = $alt->kode_alternatif;
            $denom = $dPositif[$kodeAlt] + $dNegatif[$kodeAlt];
            $preferensi[$kodeAlt] = $denom > 0 ? $dNegatif[$kodeAlt] / $denom : 0;
        }

        // Urutkan dari tertinggi ke terendah
        arsort($preferensi);

        // Kirim ke view
        return view('perhitungan.index', compact(
            'matriks', 'totalKolom', 'bobot', 'lamdaMax', 'ci', 'ri', 'cr',
            'alternatifs', 'kriterias', 'topsis', 'normalisasi', 'terbobot',
            'idealPositif', 'idealNegatif', 'dPositif', 'dNegatif', 'preferensi'
        ));
    }
}
