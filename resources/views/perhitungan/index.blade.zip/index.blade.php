@extends('layouts.app')

@section('title', 'Perhitungan AHP & TOPSIS')
@section('page-title', 'Hasil Perhitungan')

@section('content')
<div class="container-fluid">

    {{-- Pesan sukses / error --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

 {{-- Matriks Perbandingan Kriteria --}}
<div class="card mb-3">
    <div class="card-header bg-primary text-white">Matriks Perbandingan Kriteria</div>
    <div class="card-body">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Kriteria</th>
                    @foreach($kriterias as $k)
                        <th>{{ $k->kode_kriteria }}</th>
                    @endforeach
                </tr>
            </thead>
            <tbody>
                @foreach($matriks as $k1 => $baris)
                    <tr>
                        <td>{{ $k1 }}</td>
                        @foreach($kriterias as $k)
                            @php
                                $val = $baris[$k->kode_kriteria] ?? 0;
                            @endphp
                            <td>
                                {{ (floor($val) != $val) ? number_format($val, 2) : $val }}
                            </td>
                        @endforeach
                    </tr>
                @endforeach

                {{-- Baris Total --}}
                <tr class="fw-bold">
                    <td>Total</td>
                    @foreach($totalKolom as $total)
                        <td>
                            {{ (floor($total) != $total) ? number_format($total, 2) : $total }}
                        </td>
                    @endforeach
                </tr>
            </tbody>
        </table>
    </div>
</div>



    {{-- 2. Matriks Bobot Prioritas --}}
    <div class="card mb-3">
        <div class="card-header bg-success text-white">Matriks Bobot Prioritas Kriteria</div>
        <div class="card-body">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Kriteria</th>
                        <th>Bobot</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($bobot as $k => $b)
                        <tr>
                            <td>{{ $k }}</td>
                            <td>{{ number_format($b, 4) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

{{-- Matriks Konsistensi --}}
<div class="card mb-3">
    <div class="card-header bg-warning text-dark">Matriks Konsistensi</div>
    <div class="card-body">
        <p><strong>λ max (Lamda Max):</strong> {{ number_format($lamdaMax, 4) }}</p>
        <p><strong>CI (Consistency Index):</strong> {{ number_format($ci, 4) }}</p>
        <p><strong>RI (Random Index):</strong> {{ number_format($ri, 4) }}</p>
        <p><strong>CR (Consistency Ratio):</strong> {{ number_format($cr, 4) }}</p>
        @if($cr < 0.1)
            <p class="text-success">Konsisten ✅</p>
        @else
            <p class="text-danger">Tidak Konsisten ❌</p>
        @endif
    </div>
</div>


    {{-- 4. Perhitungan TOPSIS --}}
    <div class="card mb-3">
        <div class="card-header bg-info text-white">Perhitungan TOPSIS</div>
        <div class="card-body">

            {{-- 4.1 Matriks Normalisasi --}}
            <h6>Matriks Normalisasi</h6>
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>Alternatif</th>
                        @foreach($kriterias as $k)
                            <th>{{ $k->kode_kriteria }}</th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    @foreach($normalisasi as $alt => $vals)
                        <tr>
                            <td>{{ $alt }}</td>
                            @foreach($kriterias as $k)
                                <td>{{ number_format($vals[$k->kode_kriteria] ?? 0, 4) }}</td>
                            @endforeach
                        </tr>
                    @endforeach
                </tbody>
            </table>

            {{-- 4.2 Matriks Terbobot --}}
            <h6>Matriks Terbobot</h6>
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>Alternatif</th>
                        @foreach($kriterias as $k)
                            <th>{{ $k->kode_kriteria }}</th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    @foreach($weighted as $alt => $vals)
                        <tr>
                            <td>{{ $alt }}</td>
                            @foreach($kriterias as $k)
                                <td>{{ number_format($vals[$k->kode_kriteria] ?? 0, 4) }}</td>
                            @endforeach
                        </tr>
                    @endforeach
                </tbody>
            </table>

            {{-- 4.3 Solusi Ideal --}}
            <h6>Solusi Ideal Positif & Negatif</h6>
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>Kriteria</th>
                        <th>Ideal +</th>
                        <th>Ideal -</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($kriterias as $k)
                        <tr>
                            <td>{{ $k->kode_kriteria }}</td>
                            <td>{{ number_format($idealPos[$k->kode_kriteria] ?? 0, 4) }}</td>
                            <td>{{ number_format($idealNeg[$k->kode_kriteria] ?? 0, 4) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            {{-- 4.4 Jarak ke Solusi Ideal & Skor --}}
            <h6>Jarak & Skor</h6>
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>Alternatif</th>
                        <th>D+</th>
                        <th>D-</th>
                        <th>Skor</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($score as $alt => $val)
                        <tr>
                            <td>{{ $alt }}</td>
                            <td>{{ number_format($distPos[$alt] ?? 0, 4) }}</td>
                            <td>{{ number_format($distNeg[$alt] ?? 0, 4) }}</td>
                            <td>{{ number_format($val, 4) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            {{-- 4.5 Ranking --}}
            <h6>Ranking Alternatif</h6>
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Alternatif</th>
                        <th>Skor</th>
                    </tr>
                </thead>
                <tbody>
                    @php $rank=1; @endphp
                    @foreach($score as $alt => $val)
                        <tr>
                            <td>{{ $rank++ }}</td>
                            <td>{{ $alt }}</td>
                            <td>{{ number_format($val, 4) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

        </div>
    </div>

</div>
@endsection
